package com.codechallange;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.codechallange.api.CategoryAPI;
import com.codechallange.api.CategoryRepository;
import com.codechallange.domain.Catergory;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= SpringRestJpaApplicationTest.class)
public class CatergoryAPITest  {
	
	
	@InjectMocks
	private CategoryAPI tested;
	
	@Mock
	public CategoryRepository categoryRepository;
	
	public MockMvc mockMvc;
	
	@Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.standaloneSetup(tested).build();
    }
	
	
	@Test
	public void testACategoryGetMethod() throws Exception {
//		Catergory category = restTemplate.getForObject("http://localhost:8080/api/v1/category/1", Catergory.class);
		Catergory catergory = new Catergory(1l,"Computers");
		
		when(categoryRepository.getCategory(1l)).thenReturn(catergory);
		
		System.out.println(mockMvc.perform(get(CategoryAPI.BASE_URL+"/"+catergory.getId())
                .contentType(MediaType.APPLICATION_JSON))
		.andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString());
	}
	

}
