/*
 * package com.codechallange;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * @SpringBootTest class SpringRestJpaApplicationTests {
 * 
 * @Test void contextLoads() { }
 * 
 * }
 */