package com.codechallange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestJpaApplication.class, args);
	}

}
