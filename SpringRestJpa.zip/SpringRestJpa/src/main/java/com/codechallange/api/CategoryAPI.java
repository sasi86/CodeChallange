package com.codechallange.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.codechallange.domain.Catergory;

@RestController(CategoryAPI.BASE_URL)
public class CategoryAPI {
	
	public static final String BASE_URL = "/api/v1/category";
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@GetMapping
	@ResponseStatus(HttpStatus.OK)
	public List<Catergory> getAll() {
		return categoryRepository.findAll();
	}
	
	@GetMapping("{id}")
	@ResponseStatus(HttpStatus.OK)
	public Catergory getOne(@PathVariable("id") long id) {
		return categoryRepository.getCategory(id);
	}
	
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Catergory createCategory(Catergory category) {
		return categoryRepository.createNewCategory(category);
	}
	
	@DeleteMapping("{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public void deleteCategory(@PathVariable("id") long id) {
		 categoryRepository.deleteCategory(id);
	}
	
	

}
