package com.codechallange;

import static org.junit.Assert.assertEquals;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.hamcrest.HamcrestArgumentMatcher;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.codechallange.api.CategoryAPI;
import com.codechallange.api.CategoryRepository;
import com.codechallange.domain.Catergory;
import static org.hamcrest.Matchers.*;
@RunWith(SpringRunner.class)
@SpringBootTest(classes= SpringRestJpaApplicationTest.class)
public class CatergoryAPITest  {
	
	
	@InjectMocks
	private CategoryAPI tested;
	
	@Mock
	public CategoryRepository categoryRepository;
	
	public MockMvc mockMvc;
	
	@Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        mockMvc = MockMvcBuilders.standaloneSetup(tested).build();
    }
	
	
	@Test
	public void testACategoryGetMethod() throws Exception {
		String expectedJson = "[{\"id\":1,\"name\":\"Computers\",\"products\":[]}]";
//		Catergory category = restTemplate.getForObject("http://localhost:8080/api/v1/category/1", Catergory.class);
		Catergory catergory = new Catergory(1l,"Computers");
		List<Catergory> categoryList = new ArrayList<>();
		categoryList.add(catergory);
		
		when(categoryRepository.findAll()).thenReturn(categoryList);
		
		String actualResult = mockMvc.perform(get("/api/v1/category")
                .contentType(MediaType.APPLICATION_JSON))
		.andDo(MockMvcResultHandlers.print())
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
		
		assertThat(actualResult, equalTo(expectedJson));
		
		
	}
	

}
