package com.codechallange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class SpringRestJpaApplicationTest {
	


	public static void main(String[] args) {
		SpringApplication.run(SpringRestJpaApplication.class, args);
	}
	
	@Bean
	public RestTemplate buildRestClient(RestTemplateBuilder builder) {
		return builder.build();
	}

}
