package com.codechallange.api;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.codechallange.domain.Catergory;

@Repository
public class CategoryRepository {
	
	@Autowired
	private EntityManager entityManager;
	
	public List<Catergory> findAll(){
		TypedQuery<Catergory> namedQuery = entityManager.createNamedQuery("find_all_category", Catergory.class);
		return namedQuery.getResultList();
	}

	public Catergory createNewCategory(Catergory category) {
		entityManager.persist(category);
		return category;
	}

	public Catergory getCategory(long id) {
		return entityManager.find(Catergory.class, id);
	}
	
	public void deleteCategory(long id) {
		Catergory category = getCategory(id);
		entityManager.remove(category);
	}
	
	

}
